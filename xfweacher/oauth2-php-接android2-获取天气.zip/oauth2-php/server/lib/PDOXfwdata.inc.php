<?php

/**
 * @file
 * Sample OAuth2 Library PDO DB Implementation.
 */

// Set these values to your database access info.
define("PDO_DSN1", "mysql:dbname=xfdata;host=localhost");
define("PDO_USER1", "root");
define("PDO_PASS1", "hjj2563759");



/**
 * OAuth2 Library PDO DB Implementation.
 */
class PDOXfwdata {

  private $db;

  /**
   * Overrides OAuth2::__construct().
   */
  public function __construct() {
  
    try {
      $this->db = new PDO(PDO_DSN1, PDO_USER1, PDO_PASS1);
    } catch (PDOException $e) {
      die('Connection failed: ' . $e->getMessage());
    }
  }

  /**
   * Release DB connection during destruct.
   */
  function __destruct() {
    $this->db = NULL; // Release db connection
  }

  /**
   * Handle PDO exceptional cases.
   */
  private function handleException($e) {
    error_log("==handleException==".$e->getMessage(), 3, "err.log");
    echo "Database error: " . $e->getMessage();
    exit;
  }

public function getCityCode($city) {
    try {
      $sql = "SELECT citycode FROM City WHERE city = :city";	  

      $stmt = $this->db->prepare($sql);
      $stmt->bindParam(":city", $city, PDO::PARAM_STR);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
	 
       return $result["citycode"];
    } catch (PDOException $e) {
		$this->handleException($e);
    }
  }
  public function getWeather($city) {
    try {
      $sql = "select * from Weather where addtime > date_sub(curdate(),interval 7 day) and citycode = :citycode  ORDER BY addtime desc";	  

      $stmt = $this->db->prepare($sql);
      $stmt->bindParam(":citycode", $city, PDO::PARAM_STR);
      $stmt->execute();
      //$result = $stmt->fetch(PDO::FETCH_ASSOC);
	   while($row = $stmt->fetch(PDO::FETCH_ASSOC)){       
		   $result[] = $row; 
	   }    
        return $result;

     

    } catch (PDOException $e) {
		$this->handleException($e);
    }
  }

}
