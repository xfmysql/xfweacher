<?php
header("Content-type: text/html; charset=utf-8"); 
include("common.php");
// 接收上一步返回的错误信息
if ($_REQUEST ['error'])
    die ( $_REQUEST ['error'] );
// 用于发送post请求的方法,取得访问令牌需要用post请求
function http_post($url, $data) {
    $data_url = http_build_query ( $data );
    $data_len = strlen ( $data_url );
    return array ('content' => file_get_contents ( $url, false, stream_context_create ( array ('http' => array ('method' => 'POST', 'header' => "Connection: close\r\nContent-Length: $data_len\r\n", 'content' => $data_url ) ) ) ), 'headers' => $http_response_header );
}
// code是服务端返回的临时令牌
$code = $_REQUEST ["code"];
// Step2：通过Authorization Code获取Access Token
if ($_REQUEST ['state'] == $_SESSION ['state']) {
    $re = http_post ( "http://localhost:9080/oauth/oauth2-php/server/token.php",
        array (
            'client_id' => $app_id,
            'client_secret' => $app_secret,
            'code' => $code,
            'grant_type' => 'authorization_code',
            // redirect_uri一定要是当前页面的地址,否则会认证失败
            'redirect_uri' => 'http://localhost:9080/oauth/oauth2-php/client/step2.php'
        )
     );

    $re = ( array ) json_decode ( $re ['content'] );

    if($re['access_token'])
    {
        $_SESSION['access_token']=$re ['access_token'];
        echo "token:".$re ['access_token'],"<br /><a href='step3.php'>访问受保护的资源</a>";
    }
    else
    {
        echo "token fail !";
    }
}
?>