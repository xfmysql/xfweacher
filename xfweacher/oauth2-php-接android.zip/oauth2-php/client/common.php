<?php
error_reporting ( E_ALL - E_NOTICE );
session_start ();
// Ӧ�õ�APPID
$app_id = "lianx315";
// Ӧ�õ�APPKEY
$app_secret = "123456";
?>