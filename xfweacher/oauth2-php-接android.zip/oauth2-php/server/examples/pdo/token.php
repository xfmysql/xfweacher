<?php

/**
 * @file
 * Sample token endpoint.
 *
 * Obviously not production-ready code, just simple and to the point.
 *
 * In reality, you'd probably use a nifty framework to handle most of the crud for you.
 */

require "lib/PDOOAuth2.inc.php";

$oauth = new PDOOAuth2();
if ($_POST) {
	$oauth->grantAccessToken();
}

?>
<html>
  <head>Authorize</head>
  <body>
    <form method="post" action="token.php">
 
      <input name="grant_type" type="text" value="authorization_code" /> <br />
      <input name="scope" type="text" value="1" /> <br />
      <input name="code" type="text" value="" /> <br />
      <input name="redirect_url" type="text" value="" /> <br />
      <input name="username" type="text" value="a1" /> <br />
      <input name="password" type="text" value="123456" /> <br />
      <input name="assertion_type" type="text" value="" /> <br />
      <input name="assertion" type="text" value="" /> <br />
 <input name="refresh_token" type="text" value="" /> <br />



 <input type="text"  name="client_id" value="a1" /> <br />
<input type="text" name="client_secret" value="123456" /> <br />
	  
	  




      <p>
        <input type="submit" name="accept" value="Yep" />
        <input type="submit" name="accept" value="Nope" />
      </p>
    </form>
  </body>
</html>
