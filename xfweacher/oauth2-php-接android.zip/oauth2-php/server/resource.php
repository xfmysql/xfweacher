<?php

/**
 * @file
 * Sample protected resource.
 *
 * Obviously not production-ready code, just simple and to the point.
 *
 * In reality, you'd probably use a nifty framework to handle most of the crud for you.
 */

require "lib/PDOOAuth2.inc.php";
require "lib/PDOXfwdata.inc.php";
$oauth = new PDOOAuth2();

if(!$oauth->verifyAccessToken()){
	echo 'permission denied';
}

$wdata = new PDOXfwdata();
if ($_POST) {

	if($_POST["api"] == "getweather"){
		$code=$wdata->getCityCode($_POST["city"]);
		getWeather($wdata,$code);
	}
}


function getWeather($wdata,$city){
	$result = $wdata->getWeather('0575');
$data = array("success"=>1,"data"=>$result);
	echo json_encode($data);exit;
}

?>
